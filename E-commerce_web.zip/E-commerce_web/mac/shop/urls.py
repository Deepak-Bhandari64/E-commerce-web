from django.urls import path
from . import views

from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path("", views.index,name="Shop Home"),
    path("about/", views.about,name="About"),
    path("contact/", views.contact,name="ContactUs"),
    path("tracker/", views.tracker,name="Tracker"),
    path("search/", views.search, name="Search"),
    path("products/<int:myid>", views.productView, name="ProdunctView"),
    path("checkout/", views.checkout,name="Checkout"),

]
